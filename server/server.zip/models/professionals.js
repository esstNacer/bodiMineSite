// src/models/professionals.js
import pool from '../db.js';
import bcrypt from 'bcryptjs';

export const Professionals = {
  findAll: async () => {
    const [rows] = await pool.query('SELECT * FROM professionals');
    return rows;
  },

  findDoctor: async () => {
    const [rows] = await pool.query('SELECT * FROM professionals WHERE type="Professional"');
    return rows;
  },

  findById: async (id) => {
    const [rows] = await pool.query(
      'SELECT * FROM professionals WHERE professional_id = ?',
      [id]
    );
    return rows[0];
  },

  findOne: async (email) => {
    const [rows] = await pool.query(
      'SELECT * FROM professionals WHERE email = ?',
      [email]
    );
    return rows[0];
  },

  create: async (data) => {
    const {
      full_name,
      clinic_address,
      city,
      country,
      email,
      password,
      phone_number,
      specialization,
      practice_tenure,
      practice_start_date,
      is_premium = false,
      type  // valeur par défaut si non fournie
    } = data;
  
    // Hachage du mot de passe
    const hashedPassword = await bcrypt.hash(password, 10);
  
    // Insertion dans la table professionals
    const [result] = await pool.query(
      `INSERT INTO professionals (
        full_name, clinic_name, city, country, email, password,
        phone_number, specialization, practice_tenure, practice_start_date, is_premium, type
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        full_name,
        clinic_address,
        city,
        country,
        email,
        hashedPassword,
        phone_number,
        specialization,
        practice_tenure,
        practice_start_date,
        is_premium,
        type
      ]
    );
  
    return { insertId: result.insertId };
  },
  

  update: async (id, data) => {
    const fields = [];
    const values = [];
  
    // Si on reçoit un nouveau password, on le hache aussi
    if (data.password) {
      data.password = await bcrypt.hash(data.password, 10);
    }
  
    // 🔧 Corriger le format de la date
    if (data.birth_date && data.birth_date.includes('T')) {
      data.birth_date = data.birth_date.split('T')[0];
    }
  
    for (const [k, v] of Object.entries(data)) {
      fields.push(`${k} = ?`);
      values.push(v);
    }
  
    values.push(id);
  
    const [result] = await pool.query(
      `UPDATE professionals SET ${fields.join(', ')} WHERE professional_id = ?`,
      values
    );
    return result;
  },
  

  delete: async (id) => {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();
  
      // 1) Supprimer d'abord toutes les dépendances
      await connection.query('DELETE FROM notifications WHERE professional_id = ?', [id]);
      await connection.query('DELETE FROM professional_photos WHERE professional_id = ?', [id]);
      await connection.query('DELETE FROM premium_subscriptions WHERE professional_id = ?', [id]);
      await connection.query('DELETE FROM chats WHERE professional_id = ?', [id]);
      await connection.query('DELETE FROM promotions WHERE professional_id = ?', [id]);
      await connection.query('DELETE FROM premium_subscriptions_with_discount WHERE professional_id = ?', [id]);
  
      // 2) Puis supprimer le professionnel lui-même
      const [result] = await connection.query('DELETE FROM professionals WHERE professional_id = ?', [id]);
  
      await connection.commit();
      return result;
    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }
  
};
